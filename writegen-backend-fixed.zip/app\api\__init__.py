# app/api/__init__.py
# Do NOT import FastAPI or include routers here.
# This file must stay EMPTY or only declare namespace.

# Optional namespace import:
# from .health import router as health_router
