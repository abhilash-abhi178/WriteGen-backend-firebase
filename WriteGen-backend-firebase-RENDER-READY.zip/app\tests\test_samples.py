def test_dummy():
    assert 2 + 2 == 4
