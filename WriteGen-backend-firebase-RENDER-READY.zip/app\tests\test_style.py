def test_style_basics():
    assert isinstance("WriteGen", str)
